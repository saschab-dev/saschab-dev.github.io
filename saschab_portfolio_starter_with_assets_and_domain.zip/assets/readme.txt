This folder is for project images, screenshots, and other media assets.
